﻿namespace BlogWebAPI.Models
{
    public class Login
    {
        
        public string username { get; set; }

        public string password { get; set; }
    }
}
