# Employee Management System 

Simple CRUD oparation base system to manage employees using .Net WPF and Entityframework.
