# ISYS6169 - Database Systems
## Final Project - Employee Management System

### Contributors:
* Rio Adi Nugraha
* Hengky Sanjaya
* Ryan Rusli 
* Naufal F. Basyah

